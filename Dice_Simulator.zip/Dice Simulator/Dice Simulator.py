import random
from PIL import ImageTk
from tkinter import *


root=Tk()
root.title('Dice Roll Program')
root.geometry('400x400')
root.config(background='#BAD8D8')

#importing and storing dice images
img1=ImageTk.PhotoImage(file='one.png')
img2=ImageTk.PhotoImage(file='two.png')
img3=ImageTk.PhotoImage(file='three.png')
img4=ImageTk.PhotoImage(file='four.png')
img5=ImageTk.PhotoImage(file='five.png')
img6=ImageTk.PhotoImage(file='six.png')

label=Label(root,text='Dice Simulator',font=("calibri bold",30),justify='center',width=20,bg='black',fg='white')
label.place(x=0,y=0)

#specific frame as container of Images(button)
frame=LabelFrame(root,width=100,height=100,bd=0,bg='#BAD8D8')
frame.place(x=150,y=130)


def diceRoll():
    dice=random.randint(1,6)    
    
    if dice==1:
        img=img1
    elif dice==2:
        img=img2
    elif dice==3:
        img=img3
    elif dice==4:
        img=img4
    elif dice==5:
        img=img5
    elif dice==6:
        img=img6
    label=Label(text=f'You got {dice}',width=37,bg='black',fg='white',font=15,justify='center')
    label.place(x=0,y=250)
    btn=Button(frame,image=img,command=diceRoll,bd=0,cursor='hand2',bg='#BAD8D8',activebackground='#BAD8D8')
    btn.place(x=0,y=0)

btn=Button(frame,image=img1,command=diceRoll,bd=0,cursor='hand2',bg='#BAD8D8',activebackground='#BAD8D8')
btn.place(x=0,y=0)

root.mainloop()